//
//  LEANLaunchScreenManager.h
//  Median
//
//  Created by bld on 8/11/23.
//  Copyright © 2023 Median. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LEANLaunchScreenManager : NSObject
+ (LEANLaunchScreenManager *)sharedManager;
- (void)showWithParentViewController:(UIViewController *)vc;
- (void)hide;
- (void)hideAfterDelay:(double)delay;
@end
